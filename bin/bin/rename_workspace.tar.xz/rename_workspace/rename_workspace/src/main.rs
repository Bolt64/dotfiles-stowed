extern crate serde;
extern crate serde_json;
extern crate i3ipc;

use std::fs::File;
use std::io::Read;
use std::io::Result;
use std::collections::HashMap;
use std::cmp::Ordering;
use std::env;
use i3ipc::I3Connection;

fn main() {
    let log_file = "/home/sayantan/.workspace_name_history.json";

    let args: Vec<String> = env::args().collect();

    let mut log = load_json_file(&log_file).expect("I/O error");

    if args.len() <= 1 {
        for name in list_names(&log).iter() {
            println!("{}", name);
        }
    } else {
        let new_name = &args[1].to_string();
        let mut connection = I3Connection::connect().unwrap();
        rename_current_workspace(&new_name, &mut connection);
        update_name(&new_name, &mut log);
        dump_to_json(&log, &log_file);
    }
}

fn rename_current_workspace(new_name: &str, connection: &mut I3Connection) {
    let workspaces = connection.get_workspaces().unwrap();
    for workspace in workspaces.workspaces.iter() {
        if workspace.focused {
            let current_name = &workspace.name;
            let current_num = &workspace.num.to_string();
            let payload = format!("rename workspace \"{}\" to \"{}: {}\"",
                                  current_name,
                                  current_num,
                                  new_name);
            connection.run_command(&payload);
        }
    }
}

fn load_json_file(filename: &str) -> Result<HashMap<String, u32>> {
    let mut file = File::open(filename)?;
    let mut data = String::new();
    file.read_to_string(&mut data)?;
    Ok(serde_json::from_str(&data).expect("JSON was not well-formatted"))
}

fn dump_to_json(data: &HashMap<String, u32>, filename: &str) -> Result<()> {
    let encoded_json = serde_json::to_string(data)?;
    let result = std::fs::write(filename, encoded_json)?;
    Ok(result)
}

fn update_name(name: &str, log: &mut HashMap<String, u32>) {
    let name = name.to_string();
    let count = log.entry(name).or_insert(0);
    *count += 1;
}

fn list_names(log: &HashMap<String, u32>) -> Vec<String> {
    let mut names: Vec<String> = Vec::new();
    for (name, _) in log.iter() {
        names.push(name.to_string());
    }
    names.sort_by(|name1, name2| log.get(name2).unwrap().cmp(log.get(name1).unwrap()));
    names
}
